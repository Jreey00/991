define(["jquery", "layui", "carsposition"], function ($, layui, CarsPosition) {
    layui.link("Style/modules/SelectCarIcon.css?v=" + allConfig.urlArgs);

    var template = '<!-- 选择车辆图标窗口 -->' +
        '<div id="i_Layer_CarIcon" class="layui-fluid" style="display: none;">' +
        '<div class="layui-row">' +
        '<div class="layui-col-md12">' +
        '<span class="title">车辆状态颜色说明</span>' +
        '</div>' +
        '</div>' +
        '<div class="layui-row carststuecolor">' +
        '<div class="layui-col-md4">' +
        '<span class="colorblock green"></span><span>行驶</span>' +
        '</div>' +
        '<div class="layui-col-md4">' +
        '<span class="colorblock red"></span><span>停止</span>' +
        '</div>' +
        '<div class="layui-col-md4">' +
        '<span class="colorblock gray"></span><span>离线</span>' +
        '</div>' +
        '</div>' +
        '<div class="layui-row block2">' +
        '<div class="layui-col-md12">' +
        '<span class="title">车辆图标</span>' +
        '</div>' +
        '</div>' +
        '<div class="layui-row layui-form cariconbox">' +
        '<div class="layui-col-md3">' +
        '<div class="layui-input-inline">' +
        '<input type="radio" name="caricon" value="kache1" lay-filter="caricon" checked>' +
        '<img src="{{ d.kache1 }}">' +
        '</div>' +
        '</div>' +
        '<div class="layui-col-md3">' +
        '<div class="layui-input-inline">' +
        '<input type="radio" name="caricon" value="car1" lay-filter="caricon">' +
        '<img src="{{ d.car001 }}">' +
        '</div>' +
        '</div>' +
        '<div class="layui-col-md3">' +
        '<div class="layui-input-inline">' +
        '<input type="radio" name="caricon" value="car2" lay-filter="caricon">' +
        '<img src="{{ d.car0001 }}">' +
        '</div>' +
        '</div>' +
        '<div class="layui-col-md3">' +
        '<div class="layui-input-inline">' +
        '<input type="radio" name="caricon" value="sanjiao" lay-filter="caricon">' +
        '<img src="{{ d.car01 }}">' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';

    var form = layui.form;
    function loadSelectCarIcon() {
        var templateHtml = layui.laytpl(template).render({
            car01: allConfig.baseDirectory + "Resource/icon/CarPushpin/car01.png",
            car001: allConfig.baseDirectory + "Resource/icon/CarPushpin/car001.png",
            car0001: allConfig.baseDirectory + "Resource/icon/CarPushpin/car0001.png",
            kache1: allConfig.baseDirectory + "Resource/icon/CarPushpin/kache01.png"
        });
        $("body").append(templateHtml);
        form.render('radio');
        form.on('radio(caricon)', function (data) {
            CarsPosition.setIcon(data.value);
        });
    }

    loadSelectCarIcon();
});