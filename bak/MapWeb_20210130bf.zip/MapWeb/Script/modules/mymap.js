define(["imap"], function (iMap) {
    var bodyMap = document.getElementById("map");
    var map = new iMap(bodyMap, {
        ToolBar: {
            position: "RT",
            offset: {
                x: 40,
                y: 130
            }
        },
        center: { lng: 116.397428, lat: 39.90923 },
        zoom: 12,
        expandZoomRange: true,
        zooms: [3, 20],
        mapStyle: "amap://styles/macaron"
    });
    return map;
});