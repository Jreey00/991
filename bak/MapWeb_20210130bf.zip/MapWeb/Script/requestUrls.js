define(function () {
    var webHttpApiBase = allConfig.webHttpApiBase;
    var URL = {
        car: {
            paginationTable: webHttpApiBase + "/getcarinfopagination",  //获取车辆信息（查询车辆表格分页数据）
            bindTerminalList: webHttpApiBase + "/getbindcarinfolist",   //获取绑定终端的车辆信息
            getCarInfoModelByCarID: webHttpApiBase + "/getcarinfomodelbycarid",  //根据车辆ID获取一个车辆信息
            getCarCanListByMd5: webHttpApiBase + "/getcarcanlistbymd5",  //根据md5获取通道
            getCarAllStatus: webHttpApiBase + "/getcarallstatus"  //获取状态信息（多少在线车辆，多少离线车辆）
        },
        carAlarm: {
            getCarAlarmInfo: webHttpApiBase + "/getcaralarminfo"  //获取车辆报警
        },
        testSite: {
            getTestSite: webHttpApiBase + "/gettestsite"  //获取试验场信息
        },
        historicalTrack: {
            historicalTrackGetDBC: webHttpApiBase + "/historicaltrackgetdbc",  //历史轨迹回放查询获取DBC
            historicalTrackPlayback: webHttpApiBase + "/gethistoricaltrack"  //历史轨迹回放查询历史轨迹接口
        },
        user: {
            getDriverInfoByCardID: webHttpApiBase + "/getdriverinfobycardid"  //根据卡ID获取驾驶员信息
        },
        amapApi: {
            getCityID: "http://restapi.amap.com/v3/geocode/regeo?key=" + allConfig.amapWebServiceKey,  //根据经纬度获取城市ID
            getWeather: "http://restapi.amap.com/v3/weather/weatherInfo?key=" + allConfig.amapWebServiceKey  //根据城市ID获取天气
        }
    };
    return URL;
});