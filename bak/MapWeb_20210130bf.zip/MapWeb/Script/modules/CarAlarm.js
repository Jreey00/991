//车辆报警
define(["jquery", "layui", "URL"], function ($, layui, URL) {
    //引入css
    layui.link("Style/CarAlarm.css?v=" + allConfig.urlArgs);

    var template = '<div id="iFrame_ViewCarAlarm" style="display: none;">' +
        '<div id="tbCarAlarm" lay-filter="tbCarAlarm"></div>' +
        '</div>';

    //加载车辆报警
    function loadCarAlarm() {
        $("body").append(template);

        layui.table.render({
            elem: '#tbCarAlarm',
            id: "tbCarAlarm",
            skin: 'line', //行边框风格
            url: URL.carAlarm.getCarAlarmInfo,  //数据接口
            method: "post",
            page: false, //关闭分页
            //重新规定返回的数据格式
            response: {
                statusName: 'state',     //规定数据状态的字段名称，默认：code
                statusCode: 1,          //规定成功的状态码，默认：0
                msgName: 'msg',           //规定状态信息的字段名称，默认：msg
                countName: 'total',       //规定数据总数的字段名称，默认：count
                dataName: 'rows',         //规定数据列表的字段名称，默认：data
            },
            //将返回的任意数据格式解析成 table 组件规定的数据格式
            parseData: function (res) {   //res：原始返回的数据
                return {
                    "state": res.state,        //解析接口状态
                    "msg": res.msg,            //解析提示文本
                    "total": res.data.total,   //解析数据长度
                    "rows": res.data.rows      //解析数据列表
                };
            },
            cols: [[ //表头
                { type: "numbers" },
                { field: 'id', title: 'ID', hide: true },
                { field: 'carno', title: '车辆编码', width: 180, align: "center" },
                { field: 'vin', title: '车辆识别码', width: 180, align: "center" },
                {
                    field: 'type', title: '报警类型', width: 150, align: "center", templet: function (d) {
                        var type = d.type;
                        if (type == 1) {
                            return "<lable>油门异常</lable>";
                        } else if (type == 2) {
                            return "<lable>方向盘角度异常</lable>";
                        } else if (type == 3) {
                            return "<lable>灯光异常</lable>";
                        } else if (type == 4) {
                            return "<lable>车辆速度异常</lable>";
                        } else if (type == 5) {
                            return "<lable>减速度异常</lable>";
                        } else if (type == 6) {
                            return "<lable>侧向加速度异常</lable>";
                        } else if (type == 7) {
                            return "<lable>停车异常</lable>";
                        } else {
                            return "<lable>" + type + "</lable>"
                        }
                    }
                },
                { field: 'starttime', title: '开始时间', width: 170, align: "center" },
                { field: 'endtime', title: '结束时间', width: 170, align: "center" }
            ]]
        });
    }

    loadCarAlarm();
});