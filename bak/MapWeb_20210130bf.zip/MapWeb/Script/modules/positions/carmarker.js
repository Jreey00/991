﻿define(["jquery", "marker"], function ($, Marker) {
    var iconUrls = {
        car1: {
            offline: allConfig.baseDirectory + "Resource/icon/CarPushpin/car003.png",
            running: allConfig.baseDirectory + "Resource/icon/CarPushpin/car001.png",
            stop: allConfig.baseDirectory + "Resource/icon/CarPushpin/car002.png"
        },
        car2: {
            offline: allConfig.baseDirectory + "Resource/icon/CarPushpin/car0003.png",
            running: allConfig.baseDirectory + "Resource/icon/CarPushpin/car0001.png",
            stop: allConfig.baseDirectory + "Resource/icon/CarPushpin/car0002.png"
        },
        sanjiao: {
            offline: allConfig.baseDirectory + "Resource/icon/CarPushpin/car03.png",
            running: allConfig.baseDirectory + "Resource/icon/CarPushpin/car01.png",
            stop: allConfig.baseDirectory + "Resource/icon/CarPushpin/car02.png"
        },
        kache1: {
            offline: allConfig.baseDirectory + "Resource/icon/CarPushpin/kache03.png",
            running: allConfig.baseDirectory + "Resource/icon/CarPushpin/kache01.png",
            stop: allConfig.baseDirectory + "Resource/icon/CarPushpin/kache02.png"
        }
    };
    var template = '<div class="i-marker-icon">' +
        '<img class="js-angle js-icon" src="' + iconUrls.car1.running + '">' +
        '</div>';
    var defaults = {
        status: {
            angle: 0,
            isOnline: true,
            isRunning: true
        }
    };
    /**
     * 构造一个CarMarker对象,继承至Marker
     * @description 车辆图标不是单一图片,比较复杂,车辆方向需要选择内部箭头方向
     * @constructs
     * @extends {Marker} 寄生组合式继承
     */
    var CarMarker = function (map, opt) {
        var config = $.extend(true, {}, defaults, opt);
        Marker.call(this, map, config);
        var $root = $(template);
        this._dom = this._dom || {};
        this._dom._$root = $root;
        this._dom._$angle = $root.find(".js-angle");
        this._dom._icon = $root.find(".js-icon")[0];
        this._status = config.status;
        this._icon = "kache1";
        this.setStatus();
        this.setContent($root[0]);
    };
    inheritPrototype(CarMarker, Marker);
    CarMarker.prototype._isonline = true;
    /**
     * 设置图标状态
     */
    CarMarker.prototype.setStatus = function (status) {
        $.extend(this._status, status);
        if (this._status.isOnline) {
            if (this._status.isRunning) {
                this._dom._icon.src = iconUrls[this._icon].running;
            } else {
                this._dom._icon.src = iconUrls[this._icon].stop;
            }
        } else {
            this._dom._icon.src = iconUrls[this._icon].offline;
        }
        this.setAngle(this._status.angle);
    };
    /**
     * 设置角度
     * @description 设置旋转角度,重写默认旋转方法,只旋转内部的箭头
     * @param {Number} angle - GPS方向
     */
    CarMarker.prototype.setAngle = function (angle) {
        this._dom._$angle.css("transform", "rotateZ(" + angle + "deg)");
    };
    /**
     * 切换显示图片
     */
    CarMarker.prototype.setIcon = function (icon) {
        this._icon = icon;
        this.setStatus(this._status);
    };
    /**
     * 寄生组合式继承
     * @description 实现继承
     * @example 
     * var A = function(){};
     * var B = function(){A.call(this);};
     * inheritPrototype(B,A);
     * @param {class} subType 子类
     * @param {class} superType 父类
     */
    function inheritPrototype(subType, superType) {
        //创建父类原型的一个副本 等同于使用Object.create(superType.prototype)
        var prototype = Object.create(superType.prototype);
        //为副本添加constructor属性,弥补重写原型而失去的constructor属性
        prototype.constructor = subType;
        //将创建的对象(副本)赋值给子类的原型
        subType.prototype = prototype;
    }
    return CarMarker;
});