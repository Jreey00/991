(function () {
    //获取URL里的参数
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return decodeURIComponent(r[2]); return null;
    }

    require(["jquery", "layui", "echarts", "URL", "websocket", "ajaxglobalconfig"], function ($, layui, echarts, URL, wsClient, ajaxglobal) {
        //引入css
        layui.link("Style/RealtimeData.css?v=" + allConfig.urlArgs);

        //车辆ID
        var carID = getQueryString("id");
        //缓存的车辆信息
        var cacheCarInfo = null;
        //图表
        var myCharts = {
            //速度图表
            speedEchart: null,
            //折线图表
            lineEchart: null
        };
        //穿梭框信息
        var transferInfo = {
            transfer: null,
            selected: []
        };
        //车辆固定显示的数据
        var carInfo = [
            { title: "车辆编码", filed: "carno", value: "", unit: "" },
            { title: "车辆识别码", filed: "vin", value: "", unit: "" },
            { title: "终端编号", filed: "terminalcode", value: "", unit: "" },
            { title: "终端是否在线", filed: "IsOnline", value: "", unit: "" },
            { title: "车牌号", filed: "licenseno", value: "", unit: "" },
            { title: "使用类型", filed: "usetype_value", value: "", unit: "" },
            { title: "项目号", filed: "projectno_value", value: "", unit: "" },
            { title: "借用部门", filed: "borrowdep", value: "", unit: "" },
            { title: "借用人", filed: "borrowperson", value: "", unit: "" },
            { title: "车辆状态", filed: "status", value: "", unit: "" },
            // { title: "车辆来源", filed: "source", value: "", unit: "" },
            { title: "分组", filed: "groups_value", value: "", unit: "" },
            { title: "最后数据上报时间", filed: "TravelTime", value: "", unit: "" },
            { title: "经度", filed: "Lon", value: "0", unit: "°" },
            { title: "纬度", filed: "Lat", value: "0", unit: "°" },
            { title: "角度", filed: "Angle", value: "0", unit: "°" },
            { title: "GPS速度", filed: "Speed", value: "0", unit: "km/h" },
            { title: "GPS里程", filed: "Mileage", value: "0", unit: "km" },
            { title: "海拔", filed: "Altitude", value: "0", unit: "m" },
        ];

        var templateHtml =
            '{{# layui.each(d.a, function(index, rowItem){ }}' +
            '{{# if(rowItem.isCanGroup){ }}' +
            '<div class="layui-row">' +
            '<div class="layui-col-md2 div-canGroupName">' +
            '{{ rowItem.canGroupName }}' +
            '</div>' +
            '<div class="layui-col-md10 div-canGroupLine"></div>' +
            '</div>' +
            '{{# } }}' +
            '<div class="layui-row">' +
            '{{# layui.each(rowItem.items, function(indexx, item){ }}' +
            '<div class="layui-col-md3 label-title label-height">' +
            '{{# if(rowItem.isCan){ }}' +
            '<label id="lb_title_data{{ item.filed }}" >{{ item.title }}：&nbsp;&nbsp;</label>' +
            '{{# } else { }}' +
            '<label id="lb_title_{{ item.filed }}" >{{ item.title }}：&nbsp;&nbsp;</label>' +
            '{{# } }}' +
            '</div>' +
            '<div class="layui-col-md3 label-height">' +
            '{{# if(rowItem.isCan){ }}' +
            '<label id="lb_value_data{{ item.filed }}">{{ item.value }}</label>' +
            '<label id="lb_unit_data{{ item.filed }}">{{ item.unit }}</label>' +
            '{{# } else { }}' +
            '<label id="lb_value_{{ item.filed }}">{{ item.value }}</label>' +
            '<label id="lb_unit_{{ item.filed }}">{{ item.unit }}</label>' +
            '{{# } }}' +
            '</div>' +
            '{{# }); }}' +
            '</div>' +
            '{{# }); }}';

        //解析车辆信息转为HTML
        function carInfoDataAnalysisToHtml() {
            var newCarInfo = [];
            var newCarInfoItem = [];
            layui.each(carInfo, function (index, item) {
                if (index % 2 === 0) {
                    if (index != 0) {
                        newCarInfo.push({ isCanGroup: false, isCan: false, canGroupName: "发动机参数", items: newCarInfoItem });
                        newCarInfoItem = [];
                    }
                }
                newCarInfoItem.push(item);
                if (index == carInfo.length - 1)
                    newCarInfo.push({ isCanGroup: false, isCan: false, items: newCarInfoItem });
            });
            var html = layui.laytpl(templateHtml).render({ a: newCarInfo });
            $("#div_Echarts").after("<div id='div_CarInfo'></div>");
            $("#div_CarInfo").append(html);
        }

        //设置车辆信息值
        function setCarInfoData() {
            $.ajax({
                type: 'POST',
                url: URL.car.getCarInfoModelByCarID,
                cache: false,
                dataType: "json",
                data: { carid: carID },
                success: function (result) {
                    if (result.state == 1) {
                        var data = result.data;
                        cacheCarInfo = data;
                        cacheCarInfo.can = { md5: null, dbcvar: null };
                        for (var i = 0; i < carInfo.length; i++) {
                            var key = carInfo[i].filed;
                            var text = data[key];
                            if (key == "isonline") {
                                continue;
                            }
                            if (text)
                                $("#lb_value_" + key).html(text);
                        }
                        wsClient.send("2#" + data.terminalcode);
                    }
                }
            });
        }

        //WebSocket事件
        function WebSocketFireEvent() {
            //WebSocket开启
            wsClient.on("open", function (e) {
                if (cacheCarInfo && typeof cacheCarInfo.terminalcode != "undefined" && cacheCarInfo.terminalcode != null) {
                    wsClient.send("2#" + cacheCarInfo.terminalcode);
                }
            });
            //WebSocket收到消息
            wsClient.on("message", function (data) {
                var dataJson = JSON.parse(data);
                // console.log(dataJson);
                var resultData = dataJson.d;
                switch (dataJson.t) {
                    //全部数据
                    case 2:
                    //第一帧数据
                    case 4:
                    //最后一帧数据
                    case 3:
                        if (cacheCarInfo.terminalcode == resultData.TerminalCode)
                            setCarRealFullData(resultData);
                        break;
                }
            });
        }

        //设置车辆全部实时数据
        function setCarRealFullData(resultData) {
            setCarStaticData(resultData);
            if (resultData.Md5Code) {
                if (!cacheCarInfo.can.md5 || cacheCarInfo.can.md5 != resultData.Md5Code)
                    getCarCanInfoAndAnalysisToHtml(resultData.Md5Code);
                cacheCarInfo.can.md5 = resultData.Md5Code;
            }
            if (document.getElementById("div_CarCan") && resultData.CanData) {
                setCarCanInfoValue(resultData);
            }
        }

        //车辆设置固定数据
        function setCarStaticData(resultData) {
            for (var i = 0; i < carInfo.length; i++) {
                var key = carInfo[i].filed;
                var text = resultData[key];
                if (key == "IsOnline") {
                    $("#lb_value_" + key).html(text ? '<span style="color:blue">在线</span>' : '<span style="color:gray">离线</span>');
                } else if (key != "Lon" && key != "Lat" && isNumber(text)) {
                    $("#lb_value_" + key).html(text.toFixed(3));
                } else if (text) {
                    $("#lb_value_" + key).html(text);
                }
            }
            myCharts.speedEchart.setOption({
                series: [{ data: [{ value: Math.round(resultData.Speed * 100) / 100, name: 'km/h' }] }]
            });
        }

        //获取车辆DBC通道并转为Html
        function getCarCanInfoAndAnalysisToHtml(md5) {
            $.ajax({
                type: 'POST',
                url: URL.car.getCarCanListByMd5,
                cache: false,
                dataType: "json",
                data: { md5: md5 },
                success: function (result) {
                    if (result.state == 1) {
                        var data = result.data;
                        cacheCarInfo.can.dbcvar = data;

                        //生成Can列表页面元素
                        generatePageElements(data);
                    }
                }
            });
        }

        //生成Can列表页面元素
        function generatePageElements(data) {
            var newCarInfo = [];
            var newCarInfoItem = [];
            layui.each(data, function (index, item) {
                if (index % 2 === 0) {
                    if (index != 0) {
                        if (index == 2)
                            newCarInfo.push({ isCanGroup: true, isCan: true, canGroupName: "Can数据", items: newCarInfoItem });
                        else
                            newCarInfo.push({ isCanGroup: false, isCan: true, items: newCarInfoItem });
                        newCarInfoItem = [];
                    }
                }
                newCarInfoItem.push({ title: item.varname, filed: item.serial, value: "0", unit: item.unit });
                if (index == data.length - 1)
                    newCarInfo.push({ isCanGroup: false, isCan: true, items: newCarInfoItem });
            });
            var html = layui.laytpl(templateHtml).render({ a: newCarInfo });
            if (document.getElementById("div_CarCan")) {
                $("#div_CarCan").remove();
            }
            $("#div_CarInfo").after("<div id='div_CarCan'></div>");
            $("#div_CarCan").append(html);
        }

        //设置车辆DBC通道的值
        function setCarCanInfoValue(resultData) {
            var CanData = resultData.CanData;
            layui.each(CanData, function (index, item) {
                if (isNumber(item)) {
                    var text = item.toFixed(3);
                    $("#lb_value_data" + (index + 1)).html(text);
                } else {
                    $("#lb_value_data" + (index + 1)).html("");
                }
            });

            var series = myCharts.lineEchart.getOption().series;
            layui.each(transferInfo.selected, function (index, item) {
                var dbcvar = cacheCarInfo.can.dbcvar;
                if (series && series.length > 0) {
                    var serial = dbcvar[item].serial;
                    var valueData = CanData[serial - 1];
                    var seriesData = series[index].data;
                    if (seriesData.length != 0) {
                        if (resultData.TravelTime != seriesData[seriesData.length - 1][0])
                            seriesData.push([resultData.TravelTime, Math.round(valueData * 100) / 100]);
                    } else {
                        seriesData.push([resultData.TravelTime, Math.round(valueData * 100) / 100]);
                    }
                }
            });
            myCharts.lineEchart.setOption({
                series: series
            });
        }

        //加载图表
        function loadEcharts() {
            var speedEchart = echarts.init(document.getElementById('speedEchart'));
            var lineEchart = echarts.init(document.getElementById('lineEchart'));
            var speedEchartOption = {
                tooltip: {
                    formatter: "{a} <br/>{c} {b}"
                },
                series: [{
                    name: '速度',
                    type: 'gauge',
                    min: 0,
                    max: 220,
                    splitNumber: 11,
                    startAngle: 210,
                    endAngle: -30,
                    radius: '120%',
                    center: ['50%', '65%'],
                    axisLine: {
                        lineStyle: {
                            color: [[1, '#000000']],
                            width: 3,
                            shadowColor: '#000000',
                            shadowBlur: 5
                        }
                    },
                    axisLabel: {
                        textStyle: {
                            fontWeight: 'bolder',
                            color: '#000000',
                            shadowColor: '#000000',
                            shadowBlur: 3
                        }
                    },
                    axisTick: {
                        length: 10,
                        lineStyle: {
                            color: '#000000',
                            shadowColor: '#000000',
                            shadowBlur: 3
                        }
                    },
                    splitLine: {
                        length: 15,
                        lineStyle: {
                            width: 2,
                            color: '#000000',
                            shadowColor: '#000000',
                            shadowBlur: 3
                        }
                    },
                    pointer: {
                        shadowColor: '#43ffac',
                        shadowBlur: 3
                    },
                    title: {
                        offsetCenter: [0, '-30%'],
                        textStyle: {
                            fontWeight: 'bolder',
                            fontSize: 15,
                            fontStyle: 'italic',
                            color: '#000000',
                            shadowColor: '#000000',
                            shadowBlur: 3
                        }
                    },
                    detail: {
                        backgroundColor: '#000000',
                        borderColor: '#000000',
                        shadowColor: '#000000',
                        shadowBlur: 3,
                        offsetCenter: [0, '40%'],
                        formatter: function (data) {
                            return data + "km/h";
                        },
                        textStyle: {
                            fontSize: 14,
                            lineHeight: 14,
                            color: '#ffffff'
                        }
                    },
                    data: [{ value: 0, name: 'km/h' }]
                }]
            };
            var lineEchartOption = {
                legend: {
                    type: 'scroll',
                    left: "left",
                    top: 15,
                    data: []
                },
                tooltip: {
                    trigger: 'axis',
                    confine: true,
                    axisPointer: {
                        type: 'cross',
                        label: {
                            backgroundColor: '#6a7985'
                        }
                    }
                },
                grid: {
                    top: "22%",
                    left: '0%',
                    right: '5%',
                    bottom: '1%',
                    containLabel: true
                },
                xAxis: {
                    type: 'time',
                    splitLine: {
                        show: false
                    }
                },
                yAxis: {
                    type: 'value'
                },
                series: []
            };
            speedEchart.setOption(speedEchartOption);
            lineEchart.setOption(lineEchartOption);
            myCharts.speedEchart = speedEchart;
            myCharts.lineEchart = lineEchart;
        }

        //加载选择数据项穿梭框
        function loadTransfer() {
            transferInfo.transfer = layui.transfer.render({
                elem: '#transfer_SelectDataItem',  //绑定元素
                id: 'transfer_SelectDataItem', //定义索引
                width: 300,
                height: 375,
                title: ["全部", "全部"],
                text: {
                    none: '无数据', //没有数据时的文案
                    searchNone: '无数据' //搜索无匹配数据时的文案
                }
            });
        }

        //绑定按钮事件
        function loadBtn() {
            //选择数据项按钮
            $("#btnSelectDataItem").on("click", function () {
                var transferData = [];
                var dbcvar = cacheCarInfo.can.dbcvar;
                if (dbcvar) {
                    for (var i = 0; i < dbcvar.length; i++) {
                        transferData.push({ "value": i, "title": dbcvar[i].varname });
                    }
                    layui.transfer.reload("transfer_SelectDataItem", {
                        data: transferData,
                        value: transferInfo.selected
                    });
                    layer.open({
                        type: 1,
                        title: "选择数据项",
                        content: $('#layer_SelectDataItem'),
                        area: ["720px", "500px"],
                        closeBtn: 1,
                        shade: 0.3,
                        shadeClose: true,
                        anim: 5,
                        resize: false
                    });
                } else {
                    layer.msg('此车辆不在线或车辆没有上报DBC！', { icon: 2 });
                }
            });

            //确定选择按钮
            $("#btnOK").on("click", function () {
                var data = layui.transfer.getData('transfer_SelectDataItem');
                if (data && data.length > 0) {
                    var select = [];
                    var legend = [];
                    var series = [];
                    for (var i = 0; i < data.length; i++) {
                        select.push(data[i].value);
                        legend.push(data[i].title);
                        series.push({
                            name: data[i].title,
                            type: 'line',
                            showSymbol: false,
                            data: []
                        });
                    }
                    transferInfo.selected = select;
                    var lineEchartOpt = myCharts.lineEchart.getOption();
                    lineEchartOpt.legend[0].data = legend;
                    lineEchartOpt.series = series;
                    myCharts.lineEchart.setOption(lineEchartOpt, true);
                } else {
                    transferInfo.selected = [];
                    var lineEchartOpt = myCharts.lineEchart.getOption();
                    lineEchartOpt.legend[0].data = [];
                    lineEchartOpt.series = [];
                    myCharts.lineEchart.setOption(lineEchartOpt, true);
                }
                layer.close(layer.index);
            });

            //关闭按钮
            $("#btnClose").on("click", function () {
                layer.close(layer.index);
            });
        }

        //判断是否是数字
        function isNumber(val) {
            var regPos = /^\d+(\.\d+)?$/; //非负浮点数
            var regNeg = /^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/; //负浮点数
            if (regPos.test(val) || regNeg.test(val)) {
                return true;
            } else {
                return false;
            }
        }

        $(function () {
            loadEcharts();
            loadTransfer();
            loadBtn();
            carInfoDataAnalysisToHtml();
            setCarInfoData();
            WebSocketFireEvent();
        });
    });
})();