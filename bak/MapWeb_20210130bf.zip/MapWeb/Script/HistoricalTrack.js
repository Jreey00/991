﻿(function () {
    //获取URL里的参数
    function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return decodeURIComponent(r[2]); return null;
    }

    require(["jquery", "layui", "imap", "URL", "maphistory", "ajaxglobalconfig"], function ($, layui, iMap, URL, MapHistory, ajaxglobal) {
        layui.link("Style/HistoricalTrack.css?v=" + allConfig.urlArgs);
        layui.link("Resource/icon/iconfont/iconfont.css?v=" + allConfig.urlArgs);
        //车辆ID
        var carID = getQueryString("id");
        //车辆编号
        var carno = getQueryString("carno");
        //地图对象
        var map;
        //点标记对象
        var marker;
        //点标记上的信息窗体对象
        var infoWindow;
        //轨迹回放对象
        var mapHistory;
        //缓存的数据
        var cacheData = {
            path: null,                //坐标数组[{lat:xx,lng:xx,angle:xx}]
            gpsDatas: null,            //Gps数据数组[{mileage:xx,speed:xx}]
            data: null,                //历史数据
            dbcid: null,               //DBCID
            dbcmd5: null,              //DBC的MD5
            standardparameter: null    //参数标准化信息
        };
        //滑块对象
        var slider;
        //播放的参数
        var playParameter = {
            playing: false,     //是否正在播放
            pause: false,       //是否暂停
            playProgress: 0    //播放的进度
        };

        //加载搜索
        function loadSearch() {
            $("#lb_SimpleData_CarNo").html(carno);
            layui.laydate.render({
                elem: '#txt_StartTimeSearch',
                type: "datetime",
                format: "yyyy-MM-dd HH:mm:ss",
                value: GetCurrentDate()
            });
            layui.laydate.render({
                elem: '#txt_EndTimeSearch',
                type: "datetime",
                format: "yyyy-MM-dd HH:mm:ss",
                value: new Date()
            });

            //搜索
            $("#btn_Search").on("click", function () {
                clearCache();
                filterParams();
            });

            //高级搜索
            $("#btn_AdvancedSearch").on("click", function () {
                $.ajax({
                    type: 'POST',
                    url: URL.historicalTrack.historicalTrackGetDBC,
                    cache: false,
                    dataType: "json",
                    data: {
                        carid: carID,
                        starttime: $("#txt_StartTimeSearch").val(),
                        endtime: $("#txt_EndTimeSearch").val(),
                    },
                    success: function (result) {
                        if (result.state === 1) {
                            var data = result.data;
                            if (data && data.length > 0) {
                                var tplStr = '<div class="layui-form layui-fluid" style="margin-top: 15px;">' +
                                    "<fieldset class='layui-elem-field'>" +
                                    "<legend>选择DBC</legend>" +
                                    "<div class='layui-field-box' style='text-align: center;'>" +
                                    '{{#  layui.each(d, function(index, item){ }}' +
                                    '<div>' +
                                    '<input type="radio" name="radio_dbc" value="{{ item.dbcid }}" title="{{ item.filename }}" {{ index==0 ? "checked":"" }}>' +
                                    '</div>' +
                                    '{{#  }); }}' +
                                    "</div>" +
                                    "</fieldset>" +
                                    '</div>';
                                layer.open({
                                    type: 1,
                                    title: "高级查询",
                                    area: ['440px', '500px'], //宽高
                                    content: layui.laytpl(tplStr).render(data),
                                    closeBtn: 1,
                                    btn: ['确认', '取消'],
                                    btnAlign: 'c',
                                    yes: function (index, layero) {
                                        clearCache();
                                        var dbcid = $("input[name='radio_dbc']:checked").val();
                                        var md5 = "";
                                        for (var i = 0; i < data.length; i++) {
                                            if (dbcid == data[i].dbcid) {
                                                md5 = data[i].md5;
                                                cacheData.dbcid = dbcid;
                                                cacheData.dbcmd5 = md5;
                                                break;
                                            }
                                        }
                                        layer.close(layer.index);
                                        filterParams(md5);
                                    },
                                    btn2: function () {
                                        return true;
                                    },
                                    cancel: function () {
                                        return true;
                                    }
                                });
                                layui.form.render("radio");
                                return;
                            }
                        }
                        layer.msg('此时间段内没有使用DBC，只能进行普通查询!', { icon: 0 });
                    }
                });
            });
        }

        //筛选参数
        function filterParams(md5) {
            var paramsData = {
                cd: carID,
                bg: $("#txt_StartTimeSearch").val(),
                ed: $("#txt_EndTimeSearch").val()
            };
            // paramsData["fixedColumns"] = "TRAVELTIME,LATITUDE,LONGITUDE,DIRECTION,MILEAGE,SPEED";
            paramsData["fixedColumns"] = "";
            if (md5) {
                paramsData["md"] = md5;

                layer.load(2, { shade: 0.7 });

                $.ajax({
                    type: 'POST',
                    url: URL.car.getCarCanListByMd5,
                    data: { md5: md5 },
                    cache: false,
                    dataType: "json",
                    success: function (result) {
                        if (result.state == 1) {
                            var data = result.data;
                            cacheData.standardparameter = data;
                            var standardparameterStr = "";
                            for (var i = 0; i < data.length; i++) {
                                standardparameterStr += data[i].standardparametersid + ",";
                            }
                            paramsData["standards"] = standardparameterStr.substr(0, standardparameterStr.length - 1);
                            getHistoricalTrack(paramsData);
                        } else {
                            getHistoricalTrack(paramsData);
                        }
                    },
                    error: function () {
                        getHistoricalTrack(paramsData);
                    }
                });
            } else {
                layer.load(2, { shade: 0.7 });
                getHistoricalTrack(paramsData);
            }
        }

        //获取历史轨迹
        function getHistoricalTrack(paramsData) {
            $.ajax({
                type: 'POST',
                url: URL.historicalTrack.historicalTrackPlayback,
                data: paramsData,
                cache: false,
                timeout: 6 * 60 * 1000,   //超时时间：6分钟
                dataType: "json",
                success: function (result) {
                    layer.closeAll('loading');
                    if (result) {
                        if (result.resultCode == 0 && result.dataList && result.dataList.length > 0) {
                            cacheData.data = result.dataList;
                            analysisAndCalculateData(result.dataList);
                            drawHistoricalTrack();
                            refreshInfoWindow();
                        }
                        if (result.resultCode != 0) {
                            layer.msg(result.msg + '！', { icon: 0 });
                        }
                        if (result.msg) {
                            console.log("历史轨迹回放查询历史轨迹接口返回的消息：" + result.msg);
                        }
                    }
                },
                error: function () {
                    layer.msg('历史轨迹查询失败！', { icon: 0 });
                    layer.closeAll('loading');
                }
            });
        }

        //解析和计算数据
        function analysisAndCalculateData(data) {
            calculateMileageData(data);
            analysisData(data);
        }

        //绘制历史轨迹
        function drawHistoricalTrack() {
            var path = [];
            $.extend(true, path, cacheData.path);
            mapHistory.draw(path);
            map.setZoomAndCenter(15, path[0]);
        }

        //计算并显示里程数据
        function calculateMileageData(data) {
            var minMileage = 0;
            var maxMileage = 0;
            for (var i = 0; i < data.length; i++) {
                if (data[i].mil && data[i].mil != 0) {
                    minMileage = data[i].mil;
                    break;
                }
            }
            for (var i = (data.length - 1); i >= 0; i--) {
                if (data[i].mil && data[i].mil != 0) {
                    maxMileage = data[i].mil;
                    break;
                }
            }
            var mileage = maxMileage - minMileage;
            $("#lb_SimpleData_Mileage").html(mileage.toFixed(3));
        }

        //解析数据
        function analysisData(data) {
            var path = [];
            var gpsDatas = [];
            layui.each(data, function (index, item) {
                var pathData = { lng: item.lon, lat: item.lat, angle: item.dt };
                var gpsData = { traveltime: item.tm, mileage: item.mil, speed: item.speed };
                path.push(pathData);
                gpsDatas.push(gpsData);
            });
            cacheData.path = path;
            cacheData.gpsDatas = gpsDatas;
        }

        //初始化地图
        function initMap() {
            map = new iMap("map", {
                center: { lng: 116.397531, lat: 39.907704 },
                zoom: 4,
                expandZoomRange: true,
                zooms: [3, 20],
        	mapStyle: "amap://styles/blue"
            });
            marker = map.createMarker({
                lat: 39.6733704835841,
                lng: 119.200229835938,
                isCustom: false,
                visible: false,
                icon: allConfig.baseDirectory + "Resource/icon/img_car.png",
                offset: { x: -13, y: -26 }
            });
            marker.on("click", function () {
                if (infoWindow && mapHistory) {
                    var path;
                    if (!playParameter.playing && !playParameter.pause)
                        path = cacheData.path[0];
                    else
                        path = cacheData.path[mapHistory.getProgress()];
                    infoWindow.open({ lat: path.lat, lng: path.lng });
                }
            });
            infoWindow = map.createInfoWindow({
                width: "260px",
                title: '车辆信息',
                autoMove: false,
                content: [
                    { label: "车辆编号：", value: carno },
                    { label: "数据时间：", value: "" },
                    { label: "GPS车速：", value: "0km/h" },
                    { label: "GPS里程：", value: "0km" },
                ],
                icon: 'i-icon-carinfo',
                offset: {
                    x: 0,
                    y: -30
                }
            });
            mapHistory = map.createMapHistory({
                marker: marker,
                lineStyle: {
                    strokeColor: "#FF0000",
                    strokeOpacity: 1,
                    strokeWeight: 6,
                    strokeStyle: "solid",
                    showDir: true
                }
            });
            mapHistory.on("running", function (progress, total) {
                var p = ~~(progress / total * 100);
                playParameter.playProgress = p;
                slider.setValue(p);
                if (infoWindow)
                    refreshInfoWindow(progress);

                if (typeof iframeHistoricalTrackDisplayData != "undefined" && iframeHistoricalTrackDisplayData != null) {
                    var iframeDisplayData = iframeHistoricalTrackDisplayData.window || iframeHistoricalTrackDisplayData.contentWindow;
                    if (iframeDisplayData && typeof iframeDisplayData.HistoricalTrackDisplayData_SetProgress == "function")
                        iframeDisplayData.HistoricalTrackDisplayData_SetProgress(progress);
                }
            });
            mapHistory.on("end", function () {
                playParameter.pause = false;
                playParameter.playing = false;
                pauseChangeIntoStart();
            });
        }

        //初始化按钮及滑块
        function initBtnAndSlider() {
            //拖动历史轨迹回放进度的滑块
            slider = layui.slider.render({
                elem: '#slider_PlayProgress',  //绑定元素
                change: function (val) {
                    if (val !== playParameter.playProgress) {
                        playParameter.playProgress = val;
                        var value = ~~(val * mapHistory.getMax() / 100);
                        if (value >= mapHistory.getMax()) {
                            value = mapHistory.getMax() - 1;
                        }
                        mapHistory.setProgress(value);
                    }
                }
            });
            layui.form.on('select(cb_PlaySpeed)', function (element) {
                mapHistory.setSpeed(element.value);
            });
            //进入历史轨迹回放按钮单击事件
            $("#btn_EnterHistoricalTrackPlayback").on("click", function () {
                if (!mapHistory.getMax()) {
                    layer.msg('无历史轨迹数据！', { icon: 0 });
                    return;
                }
                showPlaybackToolbar();
                hideBtnAndSearchToolbar();
                marker.show();
                mapHistory.setSpeed($("#cb_PlaySpeed").val());
            });
            //退出历史轨迹回放按钮单击事件
            $("#btn_DropOutHistoricalTrackPlayback").on("click", function () {
                hidePlaybackToolbar();
                showBtnAndSearchToolbar();
                historicalTrackStop();
                marker.hide();
            });
            //开始或暂停轨迹回放按钮单击事件
            $("#btn_StartOrPause").on("click", function () {
                if (!playParameter.playing && !playParameter.pause) {
                    startChangeIntoPause();
                    historicalTrackStart();
                } else if (!playParameter.playing && playParameter.pause) {
                    startChangeIntoPause();
                    historicalTrackContinue();
                } else if (playParameter.playing && !playParameter.pause) {
                    pauseChangeIntoStart();
                    historicalTrackPause();
                }
            });
            //停止轨迹回放按钮单击事件
            $("#btn_Stop").on("click", function () {
                historicalTrackStop();
                pauseChangeIntoStart();
            });
            //同步回放数据按钮单击事件
            $("#btn_ShowDisplayData").on("click", function () {
                if (!cacheData.data) {
                    layer.msg('在此时间段内没有数据！', { icon: 2 });
                    return;
                }
                if (!cacheData.dbcid || !cacheData.dbcmd5) {
                    layer.msg('在此时间段内未绑定DBC！', { icon: 2 });
                    return;
                }
                if (!cacheData.standardparameter || cacheData.standardparameter.length == 0) {
                    layer.msg('在此时间段内没有DBC通道！', { icon: 2 });
                    return;
                }
                layer.open({
                    type: 1,
                    title: "同步回放数据",
                    id: "i_Layer_HistoricalTrackDisplayData",
                    content: "<iframe id='iframeHistoricalTrackDisplayData' name='iframeHistoricalTrackDisplayData' scrolling='auto' frameborder='0' src='HistoricalTrackDisplayData.html' style='width:100%; height:100%; display:block;'></iframe>",
                    area: ["650px", "500px"],
                    offset: 'rt',
                    shade: 0,
                    closeBtn: 1,
                    resize: false
                });
            });
        }

        //刷新窗体数据及对定位
        function refreshInfoWindow(progress) {
            if (infoWindow && cacheData.gpsDatas) {
                if (progress == null || typeof (progress) == "undefined" || !isNaN(progress))
                    progress = mapHistory.getProgress();
                var data = cacheData.gpsDatas[progress];
                var content = [
                    { label: "车辆编号：", value: carno },
                    { label: "数据时间：", value: data.traveltime },
                    { label: "GPS车速：", value: data.speed.toFixed(3) + "km/h" },
                    { label: "GPS里程：", value: data.mileage.toFixed(3) + "km" }
                ];
                infoWindow.setContent({ content: content });
                var path = cacheData.path[progress];
                infoWindow.setPosition({ lat: path.lat, lng: path.lng });
            }
        }

        //开始历史回放
        function historicalTrackStart() {
            mapHistory.start();
            playParameter.playing = true;
            playParameter.pause = false;
        }

        //暂停历史回放
        function historicalTrackPause() {
            mapHistory.pause();
            playParameter.playing = false;
            playParameter.pause = true;
        }

        //继续历史回放
        function historicalTrackContinue() {
            mapHistory.resume();
            playParameter.playing = true;
            playParameter.pause = false;
        }

        //停止历史回放
        function historicalTrackStop() {
            mapHistory.stop();
            playParameter.playing = false;
            playParameter.pause = false;
            playParameter.playProgress = 0;
            slider.setValue(playParameter.playProgress);
            refreshInfoWindow(0);
        }

        //显示回放工具栏
        function showPlaybackToolbar() {
            $("#i-PlaybackToolbar").show();
            $("#i-Btn-ShowDisplayData").show();
        }

        //隐藏回放工具栏
        function hidePlaybackToolbar() {
            $("#i-PlaybackToolbar").hide();
            $("#i-Btn-ShowDisplayData").hide();
        }

        //显示搜索历史轨迹工具栏和进入历史轨迹回放按钮
        function showBtnAndSearchToolbar() {
            $("#i-SearchTrackToolbar").show();
            $("#i-Btn-EnterPlayback").show();
        }

        //隐藏搜索历史轨迹工具栏和进入历史轨迹回放按钮
        function hideBtnAndSearchToolbar() {
            $("#i-SearchTrackToolbar").hide();
            $("#i-Btn-EnterPlayback").hide();
        }

        //暂停按钮变成开始按钮
        function pauseChangeIntoStart() {
            $("#btn_StartOrPause").removeClass("icon-tingzhi").addClass("icon-bofang1");
            $("#btn_StartOrPause").attr("title", "开始");
        }

        //开始按钮变成暂停按钮
        function startChangeIntoPause() {
            $("#btn_StartOrPause").removeClass("icon-bofang1").addClass("icon-tingzhi");
            $("#btn_StartOrPause").attr("title", "暂停");
        }

        //销毁轨迹回放
        function mapHistoryDestroy() {
            mapHistory.destroy();
            delete mapHistory;
            mapHistory = null;
        }

        //获取当前日期，格式为：yyyy-MM-dd HH:mm:ss
        function GetCurrentDate() {
            var nowDateTime = new Date();
            var yearStr = nowDateTime.getFullYear().toString();
            var month = (nowDateTime.getMonth() + 1).toString();
            var monthStr = month.length > 1 ? month : "0" + month;
            var date = nowDateTime.getDate().toString();
            var dateStr = date.length > 1 ? date : "0" + date;
            return yearStr + "-" + monthStr + "-" + dateStr + " 00:00:00";
        }

        //清空缓存的数据
        function clearCache() {
            cacheData.path = null;
            cacheData.gpsDatas = null;
            cacheData.data = null;
            cacheData.dbcid = null;
            cacheData.dbcmd5 = null;
            cacheData.standardparameter = null;
        }

        //获取历史数据（HistoricalTrackDisplayData页面用）
        GetHistoryData = function () {
            return {
                data: cacheData.data,
                dbcid: cacheData.dbcid,
                dbcmd5: cacheData.dbcmd5,
                standardparameter: cacheData.standardparameter
            };
        };

        $(function () {
            initMap();
            loadSearch();
            initBtnAndSlider();
        });
    });
})();