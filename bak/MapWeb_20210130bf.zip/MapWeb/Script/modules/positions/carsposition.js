define(["jquery", "mymap", "carmarker", "customevent", "websocket", "URL"], function ($, MyMap, CarMarker, CustomEvent, wsClient, URL) {
    //监控数据的小窗口
    var infoWindow;

    //车辆定位
    var carMarkers = { length: 0 };

    //车辆聚合
    var cluImgDir = allConfig.baseDirectory + "Resource/icon/Clusterer/";
    var Clusterer = MyMap.createMarkerClusterer({
        maxZoom: 16,
        styles: [
            { url: cluImgDir + "m1.png", size: { width: 52, height: 52 }, offset: { x: -26, y: -26 }, textColor: "#fff" },
            { url: cluImgDir + "m2.png", size: { width: 60, height: 60 }, offset: { x: -30, y: -30 }, textColor: "#fff" },
            { url: cluImgDir + "m3.png", size: { width: 70, height: 70 }, offset: { x: -35, y: -35 }, textColor: "#fff" },
            { url: cluImgDir + "m4.png", size: { width: 78, height: 78 }, offset: { x: -39, y: -39 }, textColor: "#fff" },
            { url: cluImgDir + "m5.png", size: { width: 90, height: 90 }, offset: { x: -45, y: -45 }, textColor: "#fff" },
        ]
    });

    //初始化监控数据的小窗口
    function initInfoWindow(key) {
        var car = carMarkers[key];
        var infoWindowData = {
            width: "390px",
            title: '车辆信息',
            content: '',
            icon: 'i-icon-carinfo',
            rbar: [
                {
                    iconCls: "i-icon-white-computer",
                    text: "单车监控",
                    handler: function () {
                        if (layer.index)
                            layer.close(layer.index);
                        var key = this.key;
                        var carid = carMarkers[key].carinfo.id;
                        var carno = carMarkers[key].carinfo.carno;
                        var tabLayerIndex = layer.tab({
                            // area: ['1000px', '600px'],
                            tab: [{
                                title: '<i class="iconfont" style="padding:0 10px 0 0;font-size:30px;vertical-align: middle;">&#xe665;</i>车辆监测',
                                content: "<iframe id='iframeSelectCar' name='iframeSelectCar' scrolling='auto' frameborder='0' src='RealtimeData.html?id=" + carid + "' style='width:100%; height:100%; display:block;'></iframe>"
                            }, {
                                title: '<i class="iconfont" style="padding:0 10px 0 0;font-size:30px;vertical-align: middle;">&#xe61e;</i>历史轨迹',
                                content: "<iframe id='iframeSelectCar' name='iframeSelectCar' scrolling='auto' frameborder='0' src='HistoricalTrack.html?id=" + carid + "&carno=" + carno + "' style='width:100%; height:100%; display:block;'></iframe>"
                            }]
                        });
                        layer.full(tabLayerIndex);
                    }
                }
            ],
            offset: {
                x: 0,
                y: -30
            }
        };
        if (car && car.carinfo) {
            if (car.carBaseData) {
                infoWindowData.content = [
                    { label: "车辆编号：", value: car.carinfo.carno || "" },
                    { label: "V I N 码：", value: car.carinfo.vin || "" },
                    { label: "终端编号：", value: car.carinfo.terminalcode || "" },
                    { label: "数据时间：", value: car.carBaseData.TravelTime || "" },
                    { label: "GPS车速：", value: (car.carBaseData.Speed || "0") + "km/h" },
                    { label: "GPS里程：", value: (car.carBaseData.Mileage || "0") + "km" },
                    { label: "GPS海拔：", value: (car.carBaseData.Altitude || "0") + "m" },
                    { label: "GPS方向：", value: (car.carBaseData.Angle || "0") + "°" }
                ];
            } else {
                infoWindowData.content = [
                    { label: "车辆编号：", value: car.carinfo.carno || "" },
                    { label: "V I N 码：", value: car.carinfo.vin || "" },
                    { label: "终端编号：", value: car.carinfo.terminalcode || "" },
                    { label: "数据时间：", value: "" },
                    { label: "GPS车速：", value: "0km/h" },
                    { label: "GPS里程：", value: "0km" },
                    { label: "GPS海拔：", value: "0m" },
                    { label: "GPS方向：", value: "0°" }
                ];
            }
        } else {
            infoWindowData.content = [
                { label: "车辆编号：", value: "" },
                { label: "V I N 码：", value: "" },
                { label: "终端编号：", value: "" },
                { label: "数据时间：", value: "" },
                { label: "GPS车速：", value: "0km/h" },
                { label: "GPS里程：", value: "0km" },
                { label: "GPS海拔：", value: "0m" },
                { label: "GPS方向：", value: "0°" }
            ];
        }
        infoWindow = MyMap.createInfoWindow(infoWindowData);
        infoWindow.on("close", function () {
            wsClient.send("11#");
        });
    }

    //刷新小窗口
    function refreshInfoWindow(key) {
        var car = carMarkers[key];
        if (car && infoWindow && infoWindow.key == key) {
            var content = [
                { label: "车辆编号：", value: car.carinfo.carno || "" },
                { label: "V I N 码：", value: car.carinfo.vin || "" },
                { label: "终端编号：", value: car.carinfo.terminalcode || "" },
                { label: "天   气：", value: car.carinfo.weather || "无" }
            ];
            if (car.carBaseData) {
                content.push({ label: "数据时间：", value: car.carBaseData.TravelTime || "" });
                content.push({ label: "GPS车速：", value: (car.carBaseData.Speed.toFixed(2) || "0") + "km/h" });
                content.push({ label: "GPS里程：", value: (car.carBaseData.Mileage.toFixed(2) || "0") + "km" });
                content.push({ label: "GPS海拔：", value: (car.carBaseData.Altitude.toFixed(2) || "0") + "m" });
                content.push({ label: "GPS方向：", value: (car.carBaseData.Angle.toFixed(2) || "0") + "°" });
            } else if (car.carPositionData) {
                content.push({ label: "数据时间：", value: car.carPositionData.TravelTime || "" });
                content.push({ label: "GPS车速：", value: "0km/h" });
                content.push({ label: "GPS里程：", value: "0km" });
                content.push({ label: "GPS海拔：", value: "0m" });
                content.push({ label: "GPS方向：", value: (car.carPositionData.Angle.toFixed(2) || "0") + "°" });
            }
            infoWindow.setContent({ content: content });
        }
    }

    /**
     * 关闭infoWindow
     * @param {Boolean} clusterertrigger - 是否是聚合触发的关闭
     */
    function closeInfoWindow(clusterertrigger) {
        infoWindow.clusterertrigger = clusterertrigger;
        if (infoWindow.getIsOpen()) {
            infoWindow.close();
        }
    }

    /**
     * 监控车辆列表对象
     */
    var PositionedCars = new CustomEvent();

    /**
     * 添加监控车辆,但是未定位,Marker不存在
     * @param {(String|Array)} cars - 车辆信息或数组
     */
    PositionedCars.adds = function (cars) {
        var pushs = [];
        var keys = [];
        if (cars instanceof Array) {
            cars.forEach(function (r) {
                var key = r.terminalcode;
                //过滤已存在和重复key
                if (!carMarkers[key] && !pushs[key]) {
                    pushs.push(r);
                    keys.push(key);
                }
            });
        }
        if (pushs.length) {
            pushs.forEach(function (r) {
                carMarkers[r.terminalcode] = {
                    carinfo: r,
                    carPositionData: null,
                    carBaseData: null,
                    marker: null
                };
                carMarkers.length++;
            });
            PositionedCars.fire("adds", keys);
        }
    };

    /**
     * 设置车辆Marker位置
     */
    PositionedCars.setPosition = function (opt) {
        var car = carMarkers[opt.TerminalCode];
        if (!car) return;
        if (car.marker) {
            car.marker.setPosition({
                lat: opt.Lat,
                lng: opt.Lon
            });
            car.marker.setStatus({
                isOnline: opt.IsOnline,
                angle: opt.Angle,
                isRunning: opt.IsDriving
            });
        } else {
            car.marker = createMarker(opt);
            Clusterer.addMarker(car.marker);
        }
        if (car && car.marker && infoWindow && infoWindow.key == opt.TerminalCode && infoWindow.getIsOpen()) {
            var infoOpt = { lat: opt.Lat, lng: opt.Lon };
            infoWindow.setPosition(infoOpt);
        }
    };

    /**
     * 设置车辆Marker图标
     */
    PositionedCars.setIcon = function (icon) {
        for (var key in carMarkers) {
            var marker = carMarkers[key].marker;
            if (marker)
                marker.setIcon(icon);
        }
    }

    /**
     * 查找车辆,定位车辆
     * @param {String} key -终端号
     */
    PositionedCars.find = function (key) {
        var car = carMarkers[key];
        if (car && car.marker) {
            var zoom = MyMap.getZoom();
            var needDelay = true;
            var pos = car.marker.getPosition();
            var center = MyMap.getCenter();
            if (zoom < 17) {
                zoom = 17;
            } else if (pos.lat == center.lat && pos.lng == center.lng) {
                needDelay = false;
            }
            if (needDelay) {
                MyMap.on("moveend", fireClick);
                MyMap.setZoomAndCenter(zoom, pos);
                car.marker.setAnimation("DROP");
                function fireClick() {
                    MyMap.off("moveend", fireClick);
                    setTimeout(function () {
                        car.marker.setAnimation("NONE");
                    }, 1000);
                    car.marker.click();
                }
            } else {
                car.marker.setAnimation("DROP");
                setTimeout(function () {
                    car.marker.setAnimation("NONE");
                }, 1000);
                car.marker.click();
            }
        } else {
            console.log("未找到该车的定位信息");
        }
    };

    /**
     * websocket事件
     */
    function websocketEvent() {
        //WebSocket开启
        wsClient.on("open", function (e) {
            wsClient.send("3#");
            wsClient.send("0#");

            if (infoWindow && infoWindow.getIsOpen()) {
                var carTerminal = infoWindow.key;
                if (carTerminal != null)
                    wsClient.send("1#" + carTerminal);
            }
        });
        //WebSocket收到消息
        wsClient.on("message", function (data) {
            var dataJson = JSON.parse(data);
            // console.debug(dataJson);
            var resultData = dataJson.d;
            if (dataJson.t == 1 || dataJson.t == 3 || dataJson.t == 4) {
                //1：基础数据
                //3：最后一帧数据
                //4：第一帧数据

                if (!infoWindow) return;
                var car = carMarkers[resultData.TerminalCode];
                if (car) {
                    car.carBaseData = resultData;
                    refreshInfoWindow(resultData.TerminalCode);
                }
                if (dataJson.t === 3)
                    PositionedCars.setPosition(resultData);
            } else if (dataJson.t == 0 || dataJson.t == 5) {
                //0：全部车辆坐标数据
                //5：全部绑定了终端车辆的基础数据
                resultData.forEach(function (r) {
                    var car = carMarkers[r.TerminalCode];
                    if (car) {
                        PositionedCars.setPosition(r);
                        if (dataJson.t === 0)
                            car.carPositionData = r;
                        else
                            car.carBaseData = r;
                    } else {
                        console.log("定位数据的终端编号：" + r.TerminalCode + "没有找到车辆数据");
                    }
                });
                if (dataJson.t == 5) {
                    window.setTimeout(function () {
                        MyMap.setZoom(4);
                    }, 2000);
                }
            }
        });
    }
    websocketEvent();

    /**
     * 创建Marker对象
     */
    function createMarker(opt) {
        var marker = MyMap.createMarker({
            auto: true,
            lat: opt.Lat,
            lng: opt.Lon,
            isCustom: true, //自定义Marker
            constructor: CarMarker,
            status: {
                isOnline: opt.IsOnline,
                angle: opt.Angle,
                isRunning: opt.IsDriving
            },
            offset: {
                x: -19,
                y: -19
            }
        });
        marker.key = opt.TerminalCode;
        marker.on("click", function () {
            var that = this;
            var key = that.key;
            var zoom = MyMap.getZoom();
            MyMap.setZoomAndCenter(zoom < 17 ? 17 : zoom, this.getPosition());
            infoWindow || initInfoWindow(key);
            if (infoWindow.key == key && infoWindow.getIsOpen()) {
                closeInfoWindow();
                return;
            }
            infoWindow.key = key;
            refreshInfoWindow(key);
            infoWindow.open(that.getPosition());
            infoWindow.clusterertrigger = false;
            wsClient.send("1#" + key);

            //获取天气
            if (carMarkers[key].carBaseData) {
                var getcityidurl = URL.amapApi.getCityID + "&location=" + carMarkers[key].carBaseData.Lon + "," + carMarkers[key].carBaseData.Lat;
                $.get(getcityidurl, {}, function (result) {
                    if (result.status == 1) {
                        var cityID = result.regeocode.addressComponent.adcode;
                        var getweatherurl = URL.amapApi.getWeather + "&extensions=base&city=" + cityID;
                        $.get(getweatherurl, {}, function (weathJson) {
                            if (weathJson.status == 1) {
                                var weather = weathJson.lives[0].weather;
                                carMarkers[key].carinfo.weather = weather;
                                refreshInfoWindow(key);
                            } else {
                                console.error("查询天气API失败，返回状态：" + weathJson.info);
                            }
                        }, "json");
                    } else {
                        console.error("查询逆地理编码API失败，返回状态：" + result.info);
                    }
                }, "json");
            }
        });
        return marker;
    }

    return PositionedCars;
});