(function () {
    //关闭loading
    window.setTimeout(function () {
        $('.body').show();
        $('#loadingDiv').remove();
    }, 3 * 1000);

    require(["jquery", "layui", "mymap", "URL", "websocket", "carsposition", "ajaxglobalconfig"], function ($, layui, mymap, URL, wsClient, CarsPosition, ajaxglobal) {
        //引入css
        layui.link("Style/index.css?v=" + allConfig.urlArgs);
        layui.link("Resource/icon/iconfont/iconfont.css?v=" + allConfig.urlArgs);

        //按钮事件
        function btnEvent() {
            //多车历史轨迹按钮事件
            // $("#btnMultiHistoricalTrack").on("click", function () {
            //     window.open("MultiHistoricalTrack.html");
            // });

            //车辆图标按钮事件
            $("#btnCarIcon").on("click", function () {
                layer.open({
                    type: 1,
                    title: "车辆图标",
                    id: "i_Layer_CarIcon_Div",
                    content: $("#i_Layer_CarIcon"),
                    area: ["450px", "250px"],
                    closeBtn: 1,
                    shade: 0.3,
                    shadeClose: true,
                    anim: 5,
                    resize: false
                });
            });

            //分屏监控按钮事件
            $("#btnMultiScreenMap").on("click", function () {
                window.open("MultiScreenMap.html");
            });

            //车辆报警按钮事件
            $("#btnViewCarAlarm").on("click", function () {
                layer.open({
                    type: 1,
                    title: "车辆报警",
                    content: $('#iFrame_ViewCarAlarm'),
                    area: ["900px", "500px"],
                    closeBtn: 1,
                    resize: false
                });
            });

            //查询按钮事件
            $("#btnShowSearchResult").on("click", function () {
                layer.close(layer.index);
                $("#btnShowSearchResult").parent().hide();
                openSearchResult();
            });
        }

        //搜索车辆（SearchCar.html）子页面回调的方法
        function SearchCarPageFunction() {
            //定位车辆
            SearchCarPage_CarPosition = function (terminalcode) {
                layer.close(layer.index);
                $("#btnShowSearchResult").parent().show();
                CarsPosition.find(terminalcode);
            }

            //车辆监控
            SearchCarPage_CarMonitor = function (id, carno, hasTC) {
                layer.close(layer.index);
                var tab = [];
                if (hasTC == "hasTC") {
                    tab.push({
                        title: '<i class="iconfont" style="padding:0 10px 0 0;font-size:30px;vertical-align: middle;">&#xe665;</i>车辆监测',
                        content: "<iframe id='iframeSelectCar' name='iframeSelectCar' scrolling='auto' frameborder='0' src='RealtimeData.html?id=" + encodeURIComponent(id) + "' style='width:100%; height:100%; display:block;'></iframe>"
                    });
                }
                tab.push({
                    title: '<i class="iconfont" style="padding:0 10px 0 0;font-size:30px;vertical-align: middle;">&#xe61e;</i>历史轨迹',
                    content: "<iframe id='iframeSelectCar' name='iframeSelectCar' scrolling='auto' frameborder='0' src='HistoricalTrack.html?id=" + encodeURIComponent(id) + "&carno=" + encodeURIComponent(carno) + "' style='width:100%; height:100%; display:block;'></iframe>"
                });
                var tabLayerIndex = layer.tab({
                    tab: tab,
                    cancel: function () {
                        $("#btnShowSearchResult").parent().show();
                        return true;
                    }
                });
                layer.full(tabLayerIndex);
            }
        }

        //打开搜索结果悬浮框
        function openSearchResult() {
            layer.open({
                type: 1,
                title: "查询试验车辆",
                content: "<iframe id='iframeSelectCar' name='iframeSelectCar' scrolling='auto' frameborder='0' src='SearchCar.html?CallPage=index&BottomBtnShow=false&SingleOrMultiple=none' style='width:100%; height:100%; display:block;'></iframe>",
                area: ['1000px', '600px'],
                closeBtn: 1,
                resize: false,
                cancel: function () {
                    $("#btnShowSearchResult").parent().show();
                    return true;
                }
            });
        }

        //加载一些模块
        function loadModules() {
            // require(["gpslayerswitching", "carstatuestatistics", "caralarm","selectcaricon"]);
            require(["gpslayerswitching", "carstatuestatistics", "selectcaricon"]);
        }

        //添加车辆定位
        function addCarPosition() {
            $.ajax({
                type: 'POST',
                url: URL.car.bindTerminalList,
                cache: false,
                dataType: "json",
                success: function (result) {
                    if (result.state == 1) {
                        var allData = result.data;
                        CarsPosition.adds(allData);
                        wsClient.send("3#");
                        wsClient.send("0#");
                    } else {
                        layer.msg('添加车辆定位出错，请刷新页面重试！', { icon: 2 });
                    }
                },
                error: function (e) {
                    console.error(e);
                    layer.msg('添加车辆定位出错，请刷新页面重试！', { icon: 2 });
                }
            });
        }

        //加载搜索poi自动完成
        function loadAutocomplete() {
            AMap.plugin('AMap.Autocomplete', function () {
                var autoComplete = new AMap.Autocomplete({ input: "txtAutocomplete" });
                AMap.event.addListener(autoComplete, 'select', function (e) {
                    var location = e.poi.location;
                    if (location && location != "") {
                        mymap.getProtogenesis().setZoomAndCenter(16, [location.lng, location.lat]);
                    } else {
                        layer.msg('没有此位置的定位信息，请换个位置再试！', { icon: 0 });
                    }
                });
                //回车事件
                $("#txtAutocomplete").keypress(function (e) {
                    if (e.keyCode == 13) {
                        var keyword = $("#txtAutocomplete").val();
                        autoComplete.search(keyword, function (status, result) {
                            if (status == "complete") {
                                var siteArray = result.tips;
                                for (var i = 0; i < siteArray.length; i++) {
                                    var location = siteArray[i].location;
                                    if (location && location != "") {
                                        mymap.getProtogenesis().setZoomAndCenter(16, [location.lng, location.lat]);
                                        return;
                                    }
                                }
                            } else if (status == "error") {
                                console.log(result);
                            } else if (status == "no_data") {
                                layer.msg('未找到此位置！', { icon: 0 });
                            }
                        });
                    }
                });
            });
        }

        //加载试验场
        function loadTestSite() {
            $.ajax({
                type: 'POST',
                url: URL.testSite.getTestSite,
                cache: false,
                dataType: "json",
                success: function (result) {
                    if (result.state == 1) {
                        var data = result.data;
                        for (var i = 0; i < data.length; i++) {
                            var name = data[i].name;
                            var pointStr = data[i].datapoints;
                            if (pointStr) {
                                var point = JSON.parse(pointStr);
                                if (point && point.length > 0) {
                                    var html = "<button onclick=\"btnTestSiteClick('" + point[0].x + "," + point[0].y + "')\">"
                                        + name + "</button>";
                                    $(".index-header-dropdown-content").append(html);
                                }
                            }
                        }
                    } else {
                        layer.msg('获取试验场信息出错，请刷新页面重试！', { icon: 2 });
                    }
                },
                error: function (e) {
                    console.error(e);
                    layer.msg('获取试验场信息出错，请刷新页面重试！', { icon: 2 });
                }
            });

            btnTestSiteClick = function (point) {
                var pointArr = point.split(",");
                mymap.getProtogenesis().setZoomAndCenter(16, pointArr);
            }
        }

        $(function () {
            var topVal = ($(window).height() - 100) / 2;
            $(".i-ShowSearchResult-Div").css({ "position": "fixed", "z-index": "11", "top": topVal + "px" });

            btnEvent();
            SearchCarPageFunction();
            loadModules();
            addCarPosition();
            loadAutocomplete();
            // loadTestSite();
        });

        console.log('%c警告', "color:red;");
        console.log('%c此功能仅供开发者使用,请勿在此执行任何操作！', "color:red;");
        console.log('%c版本：V' + allConfig.version, "color:blue;");
    });
})();